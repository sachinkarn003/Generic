package com.company;

public class Main {

    public static void main(String[] args) {
	  FootBallPlayer joe = new FootBallPlayer("Joe");
	  BaseballPlayer pat = new BaseballPlayer("Pat");
	  SoccerPlayer beckhan = new SoccerPlayer("Beckhan");

	  Team<FootBallPlayer> adelaideCrow = new Team("AdelaideCrow");
	  adelaideCrow.addPlayer(joe);
	 // adelaideCrow.addPlayer(pat);
	  //adelaideCrow.addPlayer(beckhan);

        System.out.println(adelaideCrow.numPlayer());

		Team<BaseballPlayer> BaseBallTeam = new Team("Chicago cups");
		BaseBallTeam.addPlayer(pat);

		Team<SoccerPlayer> BrokenTeam = new Team("This won't work");
		BrokenTeam.addPlayer(beckhan);


		Team<FootBallPlayer> melbourne = new Team<>("Melbourne");
		FootBallPlayer banks = new FootBallPlayer("Gordon");
		melbourne.addPlayer(banks);
		Team<FootBallPlayer> hawthorn = new Team<>("Hawthorn");
		Team<FootBallPlayer> fremantle = new Team<>("Framantle");


		hawthorn.matchResult(fremantle,1,0);
		hawthorn.matchResult(adelaideCrow,3,8);

		adelaideCrow.matchResult(fremantle,2,1);
		//adelaideCrow.matchResult(BaseBallTeam,1,1);
		System.out.println("Ranking");
		System.out.println(adelaideCrow.getName()+ ": "+adelaideCrow.ranking());
		System.out.println(melbourne.getName()+ ": "+melbourne.ranking());
		System.out.println(fremantle.getName()+ ": "+fremantle.ranking());
		System.out.println(hawthorn.getName()+ ": "+hawthorn.ranking());

		System.out.println(adelaideCrow.compareTo(melbourne));
		System.out.println(adelaideCrow.compareTo(hawthorn));
    }
}
