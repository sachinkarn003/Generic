package com.company;

public class FootBallPlayer extends Player {
    public FootBallPlayer(String name) {
        super(name);
    }
}
